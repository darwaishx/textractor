public class Demo {
    public static void main(String args[]) {
        try {

            for(int i=0; i<25; i++) {
                System.out.println("Run: " + (i+1));
                String documentName = "";
                //documentName = "./documents/adp-sui.pdf";
                //documentName = "./documents/ets.pdf";
                //documentName = "./documents/adp-oregon-tax-report.pdf";
                //documentName = "./documents/adp-semi-weekly.pdf";
                documentName = "./documents/textract-dg.pdf";
                long startTime = System.nanoTime();
                DemoProcessPdfSync localPdf = new DemoProcessPdfSync();
                localPdf.run(documentName, "./documents/SampleOutput.json");
                long endTime = System.nanoTime();
                long totalTime = endTime - startTime;

                System.out.println("Total time: " + totalTime / 1000000000.0);
            }

            //Generate searchable PDF from local image
//            DemoPdfFromLocalImage localImage = new DemoPdfFromLocalImage();
//            localImage.run("./documents/SampleInput.png", "./documents/SampleOutput.pdf");

//            //Generate searchable PDF from local pdf
//            DemoPdfFromLocalPdf localPdf = new DemoPdfFromLocalPdf();
//            localPdf.run("./documents/SampleInput.pdf", "./documents/SampleOutput.pdf");
//
//            //Generate searchable PDF from image in Amazon S3 bucket
//            DemoPdfFromS3Image s3Image = new DemoPdfFromS3Image();
//            s3Image.run("ki-textract-demo-docs", "SampleInput.png", "SampleOutput.pdf");
//
//            //Generate searchable PDF from pdf in Amazon S3 bucket
//            DemoPdfFromS3Pdf s3Pdf = new DemoPdfFromS3Pdf();
//            s3Pdf.run("ki-textract-demo-docs", "SampleInput.pdf", "SampleOutput.pdf");
//
//            //Generate searchable PDF from pdf in Amazon S3 bucket
//            //(by adding text to the input pdf document)
//            DemoPdfFromS3PdfAppend s3PdfAppend = new DemoPdfFromS3PdfAppend();
//            s3PdfAppend.run("ki-textract-demo-docs", "SampleInput.pdf", "SampleOutput.pdf");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
