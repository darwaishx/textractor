package com.amazon.textract.pdf;

public class FontInfo {
    int fontSize;
    float textHeight;
    float textWidth;
}

