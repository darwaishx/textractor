import com.amazonaws.ClientConfiguration;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.retry.PredefinedRetryPolicies;
import com.amazonaws.retry.RetryPolicy;
import com.amazonaws.services.textract.AmazonTextract;
import com.amazonaws.services.textract.AmazonTextractClientBuilder;
import com.amazonaws.services.textract.model.*;
import com.google.gson.Gson;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.*;

public class DemoProcessPdfSync {

    private class PageData{
        int pageNumber = -1;
        List<Block> pageBlocks = null;

        PageData(int pageNumber, List<Block> blocks){
            this.pageNumber = pageNumber;
            this.pageBlocks = blocks;
        }

        public int getPageNumber(){
            return this.pageNumber;
        }

        public List<Block> getPageBlocks(){
            return this.pageBlocks;
        }
    }

    private class Processor implements Callable<PageData> {
        ByteBuffer imageBytes = null;
        int pageNumber = 0;
        AmazonTextract client = null;

        Processor(int pageNumber, ByteBuffer imageBytes, AmazonTextract client){
            this.imageBytes = imageBytes;
            this.pageNumber = pageNumber;
            this.client = client;
        }

        @Override
        public PageData call() throws Exception {
//            AmazonTextract client = AmazonTextractClientBuilder.defaultClient();


            AnalyzeDocumentRequest request = new AnalyzeDocumentRequest()
                    .withFeatureTypes("TABLES", "FORMS")
                        .withDocument(new Document().withBytes(imageBytes));

            AnalyzeDocumentResult result = client.analyzeDocument(request);

            PageData pageData = new PageData(this.pageNumber, result.getBlocks());
            return pageData;
        }
    }

    private AmazonTextract createAwsClient(){
        AwsClientBuilder.EndpointConfiguration endpoint = new AwsClientBuilder.EndpointConfiguration(
                "https://textract.us-east-1.amazonaws.com", "us-east-1");

        ClientConfiguration clientConfiguration = new ClientConfiguration();
        clientConfiguration.setMaxErrorRetry(5);
//        clientConfiguration.setMaxConnections(200);
//        RetryPolicy retryPolicy = new RetryPolicy(PredefinedRetryPolicies.DEFAULT_RETRY_CONDITION,
//                PredefinedRetryPolicies.DEFAULT_BACKOFF_STRATEGY,
//                5,
//                false);
//        clientConfiguration.setRetryPolicy(retryPolicy);

        AmazonTextract client = AmazonTextractClientBuilder.standard()
                .withEndpointConfiguration(endpoint)
                .withClientConfiguration(clientConfiguration)
                .build();

        return client;
    }

    private void getResults(List<Future> threads, List<Block> documentBlocks) throws ExecutionException, InterruptedException, IOException {

        List<PageData> documentData = new ArrayList<PageData>();

        for(Future<PageData> thread : threads){
            documentData.add(thread.get());
        }

        //Sort by page number
        documentData.sort(Comparator.comparing(PageData::getPageNumber));

        for(PageData pageData: documentData){
            documentBlocks.addAll(pageData.getPageBlocks());
        }
    }

    private void saveResults(List<Block> documentBlocks, String outputDocumentName) throws IOException {

        //Save JSON to local disk
        Gson gson = new Gson();
        String jsonString = gson.toJson(documentBlocks);
        try (FileWriter fileWriter = new FileWriter(outputDocumentName)) {
            fileWriter.write(jsonString);
        }
    }

    public void run(String documentName, String outputDocumentName) throws IOException, ExecutionException, InterruptedException {

        System.out.println("Processing PDF document: " + documentName);

        //Output blocks
        List<Block> documentBlocks = new ArrayList<Block>();

        ExecutorService service = Executors.newFixedThreadPool(10);

        List<Future> threads = new ArrayList<Future>();

        BufferedImage image = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        ByteBuffer imageBytes = null;

        int batchSize = 10;

        AmazonTextract client = createAwsClient();

        //Load pdf document and process each page as image
        PDDocument inputDocument = PDDocument.load(new File(documentName));
        PDFRenderer pdfRenderer = new PDFRenderer(inputDocument);

        int pageNumber = 1;

        for (int pageIndex = 0; pageIndex < inputDocument.getNumberOfPages(); ++pageIndex) {

            //Render image
            image = pdfRenderer.renderImageWithDPI(pageIndex, 150, org.apache.pdfbox.rendering.ImageType.RGB);

            //Get image bytes
            byteArrayOutputStream = new ByteArrayOutputStream();
            ImageIOUtil.writeImage(image, "jpeg", byteArrayOutputStream);
            byteArrayOutputStream.flush();
            imageBytes = ByteBuffer.wrap(byteArrayOutputStream.toByteArray());

            //Schedule to extract text and data
            Future<PageData> thread = service.submit(new Processor(pageNumber, imageBytes, client));
            threads.add(thread);

            //System.out.println("Scheduled page number: " + pageNumber);

            if(pageNumber % batchSize == 0){
                System.out.println("Getting results...");
                getResults(threads, documentBlocks);
                threads.clear();
            }

            pageNumber++;
        }

        inputDocument.close();

        if(threads.size() > 0){
            System.out.println("Getting results...");
            getResults(threads, documentBlocks);
            threads.clear();
        }

        this.saveResults(documentBlocks, outputDocumentName);

        service.shutdown();

        System.out.println("Processed pdf and generated JSON: " + outputDocumentName);
    }
}
